package MainScreen;
/**
 *
 * @author Nick
 */

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import property.*;
import Agent.*;
/**This is the Class that controls the main screen GUI*/
public class MainGUIControl extends JFrame implements ActionListener{
    /**This object is what controls the main GUI and allows for creation*/    
    MainGUI m;
    /**This object is used to go into the property section*/
    PropertyMainGUIControl c;
    /**This object is used to go into the agent section*/
    AgentMainGUIControl a;
    
    boolean isManager;
    /**This constructor creates the main GUI and displays it*/
    public MainGUIControl(boolean isManager){        
        this.isManager = isManager;        
        m = new MainGUI();
        m.setVisible(true);
        m.setLocationRelativeTo(null);        
        addListeners();        
        if(!isManager){
            m.agentBtn.setVisible(false);
        }
    }
    //This method adds the listeners to the three main buttons
    public void addListeners(){        
        m.propertyBtn.addActionListener(this);
        m.agentBtn.addActionListener(this);
        m.reportBtn.addActionListener(this);        
    }    
    public void actionPerformed(ActionEvent e) {
		if(e.getSource() == m.propertyBtn){
			c = new PropertyMainGUIControl(isManager);                        
                        c.setLocationRelativeTo(null);
		}
		else if(e.getSource() == m.agentBtn){
			a = new AgentMainGUIControl();
		}
                else if(e.getSource() == m.reportBtn){
                    
                }
	}    
}

package property;
/**
 *
 * @author Nick
 */
import Query.Query;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.event.*;
/**This Class is used to open and use the Property add edit and delete GUIs*/
public class PropertyChangeGUIControl extends JFrame implements ActionListener{
        /**This object is used to use the*/
	PropertyChangeGUI pc;
        /**These store the selected address and the title to be displayed on the GUIs*/
	String selected, title;
        /**This is used to redo the search after a property has been changed*/
	PropertyMainGUIControl pmc;
        /**This object is used to do all the queries*/
        Query q;
        /**These are used to store all the inputs from the user*/
	String address, type, city;
	int bed, halfBath, bath, floor, foot,  agent;
	double price;
	boolean confirm;
        /**This is the constructor which created the GUI and add the listeners*/
	PropertyChangeGUIControl(String title, String selected, PropertyMainGUIControl pmc, String[] agentID){
		this.selected = selected;
		this.pmc = pmc;
		this.title = title;
		pc = new PropertyChangeGUI(title + " " + selected, agentID);
		pc.setVisible(true);
		pc.setLocationRelativeTo(null);                
		q = new Query();
		addListeners();
                /**This fills the fields in the GUI if the user is adding or deleting a property*/
                if(title == "Delete Property" || title == "Edit Property"){
                    fill();
                }
	}
	/**This method adds the action listeners to all the components that need them*/
	public void addListeners(){
		pc.confirmBtn.addActionListener(this);
		pc.cancelBtn.addActionListener(this);
		pc.agentIn.addActionListener(this);
	}
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == pc.confirmBtn){			
			confirm = true;
			int dialogResult;
			if(title == "Delete Property" || !checkFields()){
				switch(title){
				case "Add Property":
                                    //This allows the user 1 final chance to change their mind even if they hit the confirm button
					dialogResult = JOptionPane.showConfirmDialog(this, "Are You Sure You Wish To Add This Property?", "Warning Addition Eminent", JOptionPane.YES_NO_OPTION);
					if(dialogResult == 0) {
						q.addProperty(address, type, city, String.valueOf(agent), String.valueOf(bed), String.valueOf(halfBath), String.valueOf(bath), String.valueOf(floor), String.valueOf(foot), String.valueOf(price));
						System.out.println("Added");
					}
					else{
						confirm = false;
					}
					break;
				case "Edit Property":
                                    //This allows the user 1 final chance to change their mind even if they hit the confirm button
					dialogResult = JOptionPane.showConfirmDialog(this, "Are You Sure You Wish To Edit Property ID " + selected, "Warning Edit Eminent", JOptionPane.YES_NO_OPTION);
					if(dialogResult == 0) {
						q.editProperty(selected, address, type, city, String.valueOf(agent), String.valueOf(bed), String.valueOf(halfBath), String.valueOf(bath), String.valueOf(floor), String.valueOf(foot), String.valueOf(price));
						System.out.println("Edited");
					}
					else{
						confirm = false;
					}						
					break;
				case "Delete Property":
					//This allows the user 1 final chance to change their mind even if they hit the confirm button
					dialogResult = JOptionPane.showConfirmDialog(this, "Are You Sure You Wish To Delete The Property With " + selected + " As The Address", "Warning Deletion Eminent", JOptionPane.YES_NO_OPTION);
					if(dialogResult == 0) {
						q.deleteProperty(selected);
						System.out.println("Deleted");
					}
					else{
						confirm = false;
					}						
					break;
				}
                                //if the user hits confirm then the changes are made to the database and the search is redone to reflect the changes
				if(confirm){
					pc.setVisible(false);
					pmc.search();
				}
			}
		}		
		else if(e.getSource() == pc.cancelBtn){
			pc.setVisible(false);
		}		
	}
        /**This method is used to ensure that all fields have entries */
	public boolean checkFields(){
		boolean error = false;
		String errorMes = "";		
		if(pc.addIn.getText().length() == 0){
			error = true;
			errorMes += "Address Entry Is Invalid" + '\n';
		}
		else{
			address = pc.addIn.getText();
		}
		
		if(pc.typeIn.getText().length() == 0){
			error = true;
			errorMes += "Type Entry Is Invalid" + '\n';
		}
		else{
			type = pc.typeIn.getText();			
		}
		
		if(pc.cityIn.getText().length() == 0){
			error = true;
			errorMes += "City Entry Is Invalid" + '\n';
		}
		else{
			city = pc.cityIn.getText();			
		}
		try {
			price = Double.valueOf(pc.priceIn.getText());
		} catch (Exception e) {
			errorMes += "Price Entry Is Invalid" + '\n';
			error = true;
		}		
		try {
			bath = Integer.valueOf(pc.bathIn.getText());
		} catch (Exception e) {
			errorMes += "Bath Entry Is Invalid" + '\n';
			error  = true;
		}	
		try {
			halfBath = Integer.valueOf(pc.halfBathIn.getText());
		} catch (Exception e) {
			errorMes += "Half Bath Entry Is Invalid" + '\n';
			error  = true;
		}
		try {
			bed = Integer.valueOf(pc.bedIn.getText());
		} catch (Exception e) {
			errorMes += "Bed Entry Is Invalid" + '\n';
                        error  = true;
		}		
		try {
			foot = Integer.valueOf(pc.footIn.getText());
		} catch (Exception e) {
			errorMes += "Square Footage Entry Is Invalid" + '\n';
			error  = true;
		}		
		try {
			floor = Integer.valueOf(pc.floorIn.getText());
		} catch (Exception e) {
			errorMes += "Number of Floors Entry Is Invalid" + '\n';
			error  = true;
		}
                if(pc.agentIn.getSelectedIndex() != 0){
                    agent = pc.agentIn.getSelectedIndex();
                }
                else{
                    errorMes += "Agent Entry Is Invalid" + '\n';
		error  = true;
                }
		if(error){
			JOptionPane.showMessageDialog(null, errorMes , "Error", JOptionPane.ERROR_MESSAGE);
		}//if error
		return error;
	}
        /**This method fills the fields in the change if the user is editing or deleting a property*/
	public void fill(){
            String[] temp = q.fillChange(selected);            
            pc.addIn.setText(temp[0]);
            pc.typeIn.setText(temp[1]);
            pc.cityIn.setText(temp[2]);
            pc.priceIn.setText(temp[3]);
            pc.bathIn.setText(temp[4]);
            pc.halfBathIn.setText(temp[5]);
            pc.bedIn.setText(temp[6]);
            pc.agentIn.setSelectedIndex(Integer.valueOf(temp[7]));
            pc.footIn.setText(temp[8]);
            pc.floorIn.setText(temp[9]);
        }
}
package property;
/**
 *
 * @author Nick
 */
import javax.swing.*;

public class PropertyChangeGUI extends JFrame {

    String[] agents;
    public PropertyChangeGUI(String title, String[] agents) {
    	super(title);
        
        this.agents = agents;
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">                          
    public void initComponents() {

        jPanel1 = new JPanel();
        jPanel2 = new JPanel();
        jPanel42 = new JPanel();
        jLabel1 = new JLabel();
        jPanel3 = new JPanel();
        jPanel41 = new JPanel();
        jLabel2 = new JLabel();
        jPanel4 = new JPanel();
        jPanel40 = new JPanel();
        jLabel3 = new JLabel();
        jPanel5 = new JPanel();
        jPanel39 = new JPanel();
        jLabel4 = new JLabel();
        jPanel6 = new JPanel();
        jPanel38 = new JPanel();
        jLabel5 = new JLabel();
        jPanel7 = new JPanel();
        jPanel37 = new JPanel();
        jLabel6 = new JLabel();
        jPanel8 = new JPanel();
        jPanel36 = new JPanel();
        jLabel7 = new JLabel();
        jPanel9 = new JPanel();
        jPanel35 = new JPanel();
        jLabel8 = new JLabel();
        jPanel10 = new JPanel();
        jPanel34 = new JPanel();
        jLabel9 = new JLabel();
        jPanel11 = new JPanel();
        jPanel33 = new JPanel();
        jLabel10 = new JLabel();
        jPanel13 = new JPanel();
        jPanel21 = new JPanel();
        addIn = new JTextField();
        jPanel22 = new JPanel();
        typeIn = new JTextField();
        jPanel23 = new JPanel();
        cityIn = new JTextField();
        jPanel24 = new JPanel();
        priceIn = new JTextField();
        jPanel25 = new JPanel();
        bathIn = new JTextField();
        jPanel26 = new JPanel();
        halfBathIn = new JTextField();
        jPanel27 = new JPanel();
        bedIn = new JTextField();
        jPanel28 = new JPanel();
        agentIn = new JComboBox();
        jPanel29 = new JPanel();
        footIn = new JTextField();
        jPanel30 = new JPanel();
        floorIn = new JTextField();
        jPanel14 = new JPanel();
        jPanel15 = new JPanel();
        jPanel16 = new JPanel();
        confirmBtn = new JButton();
        cancelBtn = new JButton();
        jPanel17 = new JPanel();
        jPanel18 = new JPanel();
        jPanel19 = new JPanel();
        jPanel20 = new JPanel();

        setDefaultCloseOperation(WindowConstants.HIDE_ON_CLOSE);
        getContentPane().setLayout(new java.awt.GridLayout(1, 3));

        jPanel1.setLayout(new java.awt.GridLayout(10, 1));

        jPanel2.setLayout(new java.awt.GridLayout(1, 2));

        GroupLayout jPanel42Layout = new GroupLayout(jPanel42);
        jPanel42.setLayout(jPanel42Layout);
        jPanel42Layout.setHorizontalGroup(
            jPanel42Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGap(0, 81, Short.MAX_VALUE)
        );
        jPanel42Layout.setVerticalGroup(
            jPanel42Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGap(0, 36, Short.MAX_VALUE)
        );

        jPanel2.add(jPanel42);

        jLabel1.setText("Address");
        jPanel2.add(jLabel1);

        jPanel1.add(jPanel2);

        jPanel3.setLayout(new java.awt.GridLayout(1, 2));

        GroupLayout jPanel41Layout = new GroupLayout(jPanel41);
        jPanel41.setLayout(jPanel41Layout);
        jPanel41Layout.setHorizontalGroup(
            jPanel41Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGap(0, 81, Short.MAX_VALUE)
        );
        jPanel41Layout.setVerticalGroup(
            jPanel41Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGap(0, 36, Short.MAX_VALUE)
        );

        jPanel3.add(jPanel41);

        jLabel2.setText("House Type");
        jPanel3.add(jLabel2);

        jPanel1.add(jPanel3);

        jPanel4.setLayout(new java.awt.GridLayout(1, 2));

        GroupLayout jPanel40Layout = new GroupLayout(jPanel40);
        jPanel40.setLayout(jPanel40Layout);
        jPanel40Layout.setHorizontalGroup(
            jPanel40Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGap(0, 81, Short.MAX_VALUE)
        );
        jPanel40Layout.setVerticalGroup(
            jPanel40Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGap(0, 36, Short.MAX_VALUE)
        );

        jPanel4.add(jPanel40);

        jLabel3.setText("City");
        jPanel4.add(jLabel3);

        jPanel1.add(jPanel4);

        jPanel5.setLayout(new java.awt.GridLayout(1, 2));

        GroupLayout jPanel39Layout = new GroupLayout(jPanel39);
        jPanel39.setLayout(jPanel39Layout);
        jPanel39Layout.setHorizontalGroup(
            jPanel39Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGap(0, 81, Short.MAX_VALUE)
        );
        jPanel39Layout.setVerticalGroup(
            jPanel39Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGap(0, 36, Short.MAX_VALUE)
        );

        jPanel5.add(jPanel39);

        jLabel4.setText("Price");
        jPanel5.add(jLabel4);

        jPanel1.add(jPanel5);

        jPanel6.setLayout(new java.awt.GridLayout(1, 2));

        GroupLayout jPanel38Layout = new GroupLayout(jPanel38);
        jPanel38.setLayout(jPanel38Layout);
        jPanel38Layout.setHorizontalGroup(
            jPanel38Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGap(0, 81, Short.MAX_VALUE)
        );
        jPanel38Layout.setVerticalGroup(
            jPanel38Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGap(0, 36, Short.MAX_VALUE)
        );

        jPanel6.add(jPanel38);

        jLabel5.setText("Bathrooms");
        jPanel6.add(jLabel5);

        jPanel1.add(jPanel6);

        jPanel7.setLayout(new java.awt.GridLayout(1, 2));

        GroupLayout jPanel37Layout = new GroupLayout(jPanel37);
        jPanel37.setLayout(jPanel37Layout);
        jPanel37Layout.setHorizontalGroup(
            jPanel37Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGap(0, 81, Short.MAX_VALUE)
        );
        jPanel37Layout.setVerticalGroup(
            jPanel37Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGap(0, 36, Short.MAX_VALUE)
        );

        jPanel7.add(jPanel37);

        jLabel6.setText("Half Baths");
        jPanel7.add(jLabel6);

        jPanel1.add(jPanel7);

        jPanel8.setLayout(new java.awt.GridLayout(1, 2));

        GroupLayout jPanel36Layout = new GroupLayout(jPanel36);
        jPanel36.setLayout(jPanel36Layout);
        jPanel36Layout.setHorizontalGroup(
            jPanel36Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGap(0, 81, Short.MAX_VALUE)
        );
        jPanel36Layout.setVerticalGroup(
            jPanel36Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGap(0, 36, Short.MAX_VALUE)
        );

        jPanel8.add(jPanel36);

        jLabel7.setText("Bedrooms");
        jPanel8.add(jLabel7);

        jPanel1.add(jPanel8);

        jPanel9.setLayout(new java.awt.GridLayout(1, 2));

        GroupLayout jPanel35Layout = new GroupLayout(jPanel35);
        jPanel35.setLayout(jPanel35Layout);
        jPanel35Layout.setHorizontalGroup(
            jPanel35Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGap(0, 81, Short.MAX_VALUE)
        );
        jPanel35Layout.setVerticalGroup(
            jPanel35Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGap(0, 36, Short.MAX_VALUE)
        );

        jPanel9.add(jPanel35);

        jLabel8.setText("Listing Agent");
        jPanel9.add(jLabel8);

        jPanel1.add(jPanel9);

        jPanel10.setLayout(new java.awt.GridLayout(1, 2));

        GroupLayout jPanel34Layout = new GroupLayout(jPanel34);
        jPanel34.setLayout(jPanel34Layout);
        jPanel34Layout.setHorizontalGroup(
            jPanel34Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGap(0, 81, Short.MAX_VALUE)
        );
        jPanel34Layout.setVerticalGroup(
            jPanel34Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGap(0, 36, Short.MAX_VALUE)
        );

        jPanel10.add(jPanel34);

        jLabel9.setText("Square Footage");
        jPanel10.add(jLabel9);

        jPanel1.add(jPanel10);

        jPanel11.setLayout(new java.awt.GridLayout(1, 2));

        GroupLayout jPanel33Layout = new GroupLayout(jPanel33);
        jPanel33.setLayout(jPanel33Layout);
        jPanel33Layout.setHorizontalGroup(
            jPanel33Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGap(0, 81, Short.MAX_VALUE)
        );
        jPanel33Layout.setVerticalGroup(
            jPanel33Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGap(0, 36, Short.MAX_VALUE)
        );

        jPanel11.add(jPanel33);

        jLabel10.setText("Floors");
        jPanel11.add(jLabel10);

        jPanel1.add(jPanel11);

        getContentPane().add(jPanel1);

        jPanel13.setLayout(new java.awt.GridLayout(10, 1));

        jPanel21.setLayout(new java.awt.GridLayout());
        jPanel21.add(addIn);

        jPanel13.add(jPanel21);

        jPanel22.setLayout(new java.awt.GridLayout());
        jPanel22.add(typeIn);

        jPanel13.add(jPanel22);

        jPanel23.setLayout(new java.awt.GridLayout());
        jPanel23.add(cityIn);

        jPanel13.add(jPanel23);

        jPanel24.setLayout(new java.awt.GridLayout());
        jPanel24.add(priceIn);

        jPanel13.add(jPanel24);

        jPanel25.setLayout(new java.awt.GridLayout());
        jPanel25.add(bathIn);

        jPanel13.add(jPanel25);

        jPanel26.setLayout(new java.awt.GridLayout());
        jPanel26.add(halfBathIn);

        jPanel13.add(jPanel26);

        jPanel27.setLayout(new java.awt.GridLayout());
        jPanel27.add(bedIn);

        jPanel13.add(jPanel27);

        jPanel28.setLayout(new java.awt.GridLayout());

        agentIn.setModel(new DefaultComboBoxModel(agents));
        jPanel28.add(agentIn);

        jPanel13.add(jPanel28);

        jPanel29.setLayout(new java.awt.GridLayout());
        jPanel29.add(footIn);

        jPanel13.add(jPanel29);

        jPanel30.setLayout(new java.awt.GridLayout());
        jPanel30.add(floorIn);

        jPanel13.add(jPanel30);

        getContentPane().add(jPanel13);

        jPanel14.setLayout(new java.awt.GridLayout(8, 1));

        GroupLayout jPanel15Layout = new GroupLayout(jPanel15);
        jPanel15.setLayout(jPanel15Layout);
        jPanel15Layout.setHorizontalGroup(
            jPanel15Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGap(0, 162, Short.MAX_VALUE)
        );
        jPanel15Layout.setVerticalGroup(
            jPanel15Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGap(0, 45, Short.MAX_VALUE)
        );

        jPanel14.add(jPanel15);

        GroupLayout jPanel16Layout = new GroupLayout(jPanel16);
        jPanel16.setLayout(jPanel16Layout);
        jPanel16Layout.setHorizontalGroup(
            jPanel16Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGap(0, 162, Short.MAX_VALUE)
        );
        jPanel16Layout.setVerticalGroup(
            jPanel16Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGap(0, 45, Short.MAX_VALUE)
        );

        jPanel14.add(jPanel16);

        confirmBtn.setText("Confirm");
        jPanel14.add(confirmBtn);

        cancelBtn.setText("Cancel");
        jPanel14.add(cancelBtn);

        GroupLayout jPanel17Layout = new GroupLayout(jPanel17);
        jPanel17.setLayout(jPanel17Layout);
        jPanel17Layout.setHorizontalGroup(
            jPanel17Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGap(0, 162, Short.MAX_VALUE)
        );
        jPanel17Layout.setVerticalGroup(
            jPanel17Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGap(0, 45, Short.MAX_VALUE)
        );

        jPanel14.add(jPanel17);

        GroupLayout jPanel18Layout = new GroupLayout(jPanel18);
        jPanel18.setLayout(jPanel18Layout);
        jPanel18Layout.setHorizontalGroup(
            jPanel18Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGap(0, 162, Short.MAX_VALUE)
        );
        jPanel18Layout.setVerticalGroup(
            jPanel18Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGap(0, 45, Short.MAX_VALUE)
        );

        jPanel14.add(jPanel18);

        GroupLayout jPanel19Layout = new GroupLayout(jPanel19);
        jPanel19.setLayout(jPanel19Layout);
        jPanel19Layout.setHorizontalGroup(
            jPanel19Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGap(0, 162, Short.MAX_VALUE)
        );
        jPanel19Layout.setVerticalGroup(
            jPanel19Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGap(0, 45, Short.MAX_VALUE)
        );

        jPanel14.add(jPanel19);

        GroupLayout jPanel20Layout = new GroupLayout(jPanel20);
        jPanel20.setLayout(jPanel20Layout);
        jPanel20Layout.setHorizontalGroup(
            jPanel20Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGap(0, 162, Short.MAX_VALUE)
        );
        jPanel20Layout.setVerticalGroup(
            jPanel20Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGap(0, 45, Short.MAX_VALUE)
        );

        jPanel14.add(jPanel20);

        getContentPane().add(jPanel14);

        pack();
    }// </editor-fold>                        

   

    // Variables declaration - do not modify                     
    public JTextField addIn;
    public JComboBox agentIn;
    public JTextField bathIn;
    public JTextField bedIn;
    public JButton cancelBtn;
    public JTextField cityIn;
    public JButton confirmBtn;
    public JTextField floorIn;
    public JTextField footIn;
    public JTextField halfBathIn;
    public JLabel jLabel1;
    public JLabel jLabel10;
    public JLabel jLabel2;
    public JLabel jLabel3;
    public JLabel jLabel4;
    public JLabel jLabel5;
    public JLabel jLabel6;
    public JLabel jLabel7;
    public JLabel jLabel8;
    public JLabel jLabel9;
    public JPanel jPanel1;
    public JPanel jPanel10;
    public JPanel jPanel11;
    public JPanel jPanel13;
    public JPanel jPanel14;
    public JPanel jPanel15;
    public JPanel jPanel16;
    public JPanel jPanel17;
    public JPanel jPanel18;
    public JPanel jPanel19;
    public JPanel jPanel2;
    public JPanel jPanel20;
    public JPanel jPanel21;
    public JPanel jPanel22;
    public JPanel jPanel23;
    public JPanel jPanel24;
    public JPanel jPanel25;
    public JPanel jPanel26;
    public JPanel jPanel27;
    public JPanel jPanel28;
    public JPanel jPanel29;
    public JPanel jPanel3;
    public JPanel jPanel30;
    public JPanel jPanel33;
    public JPanel jPanel34;
    public JPanel jPanel35;
    public JPanel jPanel36;
    public JPanel jPanel37;
    public JPanel jPanel38;
    public JPanel jPanel39;
    public JPanel jPanel4;
    public JPanel jPanel40;
    public JPanel jPanel41;
    public JPanel jPanel42;
    public JPanel jPanel5;
    public JPanel jPanel6;
    public JPanel jPanel7;
    public JPanel jPanel8;
    public JPanel jPanel9;
    public JTextField priceIn;
    public JTextField typeIn;
    // End of variables declaration                   
}
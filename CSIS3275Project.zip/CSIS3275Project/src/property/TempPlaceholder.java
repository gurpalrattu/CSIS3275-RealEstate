package property;
import Query.Query;
import MainScreen.*;

import javax.swing.*;
import Login.*;
/**This Class is here just for testing to allow you to start from any screen in the program*/
public class TempPlaceholder {
		
	//static boolean isManager = true;	
	
	//static PropertyMainGUIControl c;
        static MainGUIControl m;
        static Query q;
        static LoginScreenGUIControl l;
	
	public static void main(String agrs[]){
		
                l = new LoginScreenGUIControl();
                
                //m = new MainGUIControl(false);
		
	}
	

}
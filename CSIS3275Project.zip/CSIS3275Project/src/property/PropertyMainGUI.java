package property;
/**
 *
 * @author Nick
 */
import javax.swing.*;

public class PropertyMainGUI extends JFrame {

    
    public PropertyMainGUI(String type[], String city[], String agent[]) {        
    	this.type = type;
    	this.city = city;
    	this.agent = agent;
    	
    	initComponents();
    	
    	
			
    }
    
    //variable declarations
    public String type[];
    public String city[];
    public String agent[];
    
    
    
    
    public JLabel addressOut;
    
    
    //entry fields
    public JTextField floorEntry;
    public JTextField halfBathEntry;
    public JComboBox agentEntry;
    public JTextField bathEntry;
    public JTextField bedEntry;
    public JComboBox cityEntry;
    public JTextField dateEntry;
    public JRadioButton isSoldRBtn;
    public JTextField maxPEntry;
    public JTextField minPEntry;
    //public JRadioButton notSoldRBtn;
    public JTextField sqrFootEntry;
    public JComboBox typeEntry;
    ///entry fields
    ///output fields
    public JLabel typeOut;
    public JLabel agentNameOut;
    public JLabel askPriceOut;    
    public JLabel bathOut;    
    public JLabel bedOut;
    public JLabel cityOut;
    public JPanel imgOut;
    public JLabel lDateOut;
    public JLabel floorOut;
    public JLabel halfBathOut;
    public JLabel agentIDOut;
    public JLabel footOut;
    public JLabel priceOut;
    ///output fields
    ///buttons
    public JButton addBtn;
    public JButton delBtn;
    public JButton editBtn;
    public JButton searchBtn;
    public JButton openSoldBtn;
    public JList propertyOutList;
    ///buttons
    public JLabel jLabel1;
    public JLabel jLabel10;
    public JLabel jLabel11;
    public JLabel jLabel12;
    public JLabel jLabel13;
    public JLabel jLabel14;
    public JLabel jLabel15;
    public JLabel jLabel16;
    public JLabel jLabel17;
    public JLabel jLabel18;
    public JLabel jLabel19;
    public JLabel jLabel2;
    public JLabel jLabel20;
    public JLabel jLabel21;
    public JLabel jLabel22;
    public JLabel jLabel3;
    public JLabel jLabel4;
    public JLabel jLabel5;
    public JLabel jLabel6;
    public JLabel jLabel7;
    public JLabel jLabel8;
    public JLabel jLabel9;
    
    public JPanel centerMainPanel; 
    public JPanel houseDetailPanel;
    public JPanel jPanel4;
    public JPanel jPanel1;
    public JPanel jPanel10;
    public JPanel jPanel11;
    public JPanel jPanel12;
    public JPanel jPanel13;
    public JPanel jPanel14;
    public JPanel jPanel15;
    public JPanel jPanel16;
    public JPanel jPanel2;
    public JPanel jPanel3;
    public JPanel changePanel;
    public JPanel jPanel5;
    public JPanel jPanel6;
    public JPanel jPanel7;
    public JPanel jPanel8;
    public JPanel jPanel9;
    public JPanel leftMainPanel;
    public JPanel mainPanel;     
    public JPanel rightBottomOut;
    public JPanel rightMainPanel;
    public JPanel rightTopOut;
    public JPanel searchBath;
    public JPanel searchBed;    
    public JPanel searchChangePanel;
    public JPanel searchCity;
    public JPanel searchHalfBath;
    public JPanel searchIsSold;
    public JPanel searchListAgent;
    public JPanel searchListing;
    public JPanel searchPanel;
    public JPanel searchPrice;
    public JPanel searchTitle;
    public JLabel searchTitleLbl;
    public JPanel searchType;
    public JPanel soldPropPanel;    
    public JPanel addressOutPanel;
    
    public JScrollPane jScrollPane2; 
    // End of variables declaration 
    
    
    
    
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">                          
    private void initComponents() {

        mainPanel = new javax.swing.JPanel();
        leftMainPanel = new javax.swing.JPanel();
        searchPanel = new javax.swing.JPanel();
        searchTitle = new javax.swing.JPanel();
        searchTitleLbl = new javax.swing.JLabel();
        searchType = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        typeEntry = new javax.swing.JComboBox();
        searchCity = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        cityEntry = new javax.swing.JComboBox();
        searchPrice = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        minPEntry = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        maxPEntry = new javax.swing.JTextField();
        searchBath = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        bathEntry = new javax.swing.JTextField();
        searchHalfBath = new javax.swing.JPanel();
        jLabel17 = new javax.swing.JLabel();
        halfBathEntry = new javax.swing.JTextField();
        searchBed = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        bedEntry = new javax.swing.JTextField();
        searchListing = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        dateEntry = new javax.swing.JTextField();
        searchListAgent = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        agentEntry = new javax.swing.JComboBox();
        jPanel14 = new javax.swing.JPanel();
        jLabel21 = new javax.swing.JLabel();
        sqrFootEntry = new javax.swing.JTextField();
        searchChangePanel = new javax.swing.JPanel();
        jPanel13 = new javax.swing.JPanel();
        jPanel15 = new javax.swing.JPanel();
        jLabel22 = new javax.swing.JLabel();
        floorEntry = new javax.swing.JTextField();
        searchIsSold = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        isSoldRBtn = new javax.swing.JRadioButton();
//        notSoldRBtn = new javax.swing.JRadioButton();
        jPanel16 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        searchBtn = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        addBtn = new javax.swing.JButton();
        editBtn = new javax.swing.JButton();
        delBtn = new javax.swing.JButton();
        centerMainPanel = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        propertyOutList = new javax.swing.JList();
        rightMainPanel = new javax.swing.JPanel();
        houseDetailPanel = new javax.swing.JPanel();
        imgOut = new javax.swing.JPanel();
        rightTopOut = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        typeOut = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        cityOut = new javax.swing.JLabel();
        jPanel8 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        floorOut = new javax.swing.JLabel();
        jPanel9 = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        footOut = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel18 = new javax.swing.JLabel();
        bedOut = new javax.swing.JLabel();
        rightBottomOut = new javax.swing.JPanel();
        jPanel12 = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        bathOut = new javax.swing.JLabel();
        jPanel11 = new javax.swing.JPanel();
        jLabel16 = new javax.swing.JLabel();
        agentIDOut = new javax.swing.JLabel();
        jPanel10 = new javax.swing.JPanel();
        jLabel15 = new javax.swing.JLabel();
        agentNameOut = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel19 = new javax.swing.JLabel();
        lDateOut = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jLabel20 = new javax.swing.JLabel();
        priceOut = new javax.swing.JLabel();
        addressOutPanel = new javax.swing.JPanel();
        addressOut = new javax.swing.JLabel();
        soldPropPanel = new javax.swing.JPanel();
        openSoldBtn = new javax.swing.JButton();

        //setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Property Viewer");
        getContentPane().setLayout(new java.awt.GridLayout(1, 0));

        mainPanel.setLayout(new java.awt.GridLayout(1, 0));

        leftMainPanel.setLayout(new java.awt.GridLayout(2, 1, 10, 0));

        searchPanel.setLayout(new java.awt.GridLayout(10, 1));

        searchTitleLbl.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        searchTitleLbl.setText("Search Fields");
        searchTitle.add(searchTitleLbl);

        searchPanel.add(searchTitle);

        searchType.setLayout(new java.awt.GridLayout(1, 0, 1, 3));

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel1.setText("Type");
        searchType.add(jLabel1);

        typeEntry.setModel(new javax.swing.DefaultComboBoxModel(type));
       
        searchType.add(typeEntry);

        searchPanel.add(searchType);

        searchCity.setLayout(new java.awt.GridLayout(1, 0, 1, 3));

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel2.setText("City");
        searchCity.add(jLabel2);

        cityEntry.setModel(new javax.swing.DefaultComboBoxModel(city));
        searchCity.add(cityEntry);

        searchPanel.add(searchCity);

        searchPrice.setLayout(new java.awt.GridLayout(1, 0, 1, 3));

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel3.setText("Price");
        searchPrice.add(jLabel3);
        searchPrice.add(minPEntry);

        jLabel9.setText("Min To Max");
        searchPrice.add(jLabel9);
        searchPrice.add(maxPEntry);

        searchPanel.add(searchPrice);
        searchPrice.getAccessibleContext().setAccessibleName("Price");

        searchBath.setLayout(new java.awt.GridLayout(1, 0, 1, 3));

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel4.setText("Bathrooms");
        searchBath.add(jLabel4);
        searchBath.add(bathEntry);

        searchPanel.add(searchBath);

        searchHalfBath.setLayout(new java.awt.GridLayout(1, 0, 1, 3));

        jLabel17.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel17.setText("Half Baths");
        searchHalfBath.add(jLabel17);

       
        searchHalfBath.add(halfBathEntry);

        searchPanel.add(searchHalfBath);

        searchBed.setLayout(new java.awt.GridLayout(1, 0, 1, 3));

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel5.setText("Bedrooms");
        searchBed.add(jLabel5);
        searchBed.add(bedEntry);

        searchPanel.add(searchBed);

        searchListing.setLayout(new java.awt.GridLayout(1, 0, 1, 3));

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel6.setText("Listing Date");
        searchListing.add(jLabel6);

        dateEntry.setText("YYYY-MM-DD");
        searchListing.add(dateEntry);

        searchPanel.add(searchListing);

        searchListAgent.setLayout(new java.awt.GridLayout(1, 0, 1, 3));

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel7.setText("Listing Agent");
        searchListAgent.add(jLabel7);

        agentEntry.setModel(new javax.swing.DefaultComboBoxModel(agent));
        searchListAgent.add(agentEntry);

        searchPanel.add(searchListAgent);

        jPanel14.setLayout(new java.awt.GridLayout(1, 2, 0, 3));

        jLabel21.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel21.setText("Min Square Footage");
        jPanel14.add(jLabel21);
        jPanel14.add(sqrFootEntry);

        searchPanel.add(jPanel14);

        leftMainPanel.add(searchPanel);

        searchChangePanel.setLayout(new java.awt.GridLayout(3, 1));

        jPanel13.setLayout(new java.awt.GridLayout(3, 0, 1, 3));

        jPanel15.setLayout(new java.awt.GridLayout(1, 2, 0, 3));

        jLabel22.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel22.setText("Floors");
        jPanel15.add(jLabel22);
        jPanel15.add(floorEntry);

        jPanel13.add(jPanel15);

        searchIsSold.setLayout(new java.awt.GridLayout(1, 0, 10, 3));

        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel8.setText("Sold");
        searchIsSold.add(jLabel8);

        isSoldRBtn.setText("Is Sold");
        
        searchIsSold.add(isSoldRBtn);

//        notSoldRBtn.setText("Not Sold");
//        searchIsSold.add(notSoldRBtn);

        jPanel13.add(searchIsSold);

        javax.swing.GroupLayout jPanel16Layout = new javax.swing.GroupLayout(jPanel16);
        jPanel16.setLayout(jPanel16Layout);
        jPanel16Layout.setHorizontalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 246, Short.MAX_VALUE)
        );
        jPanel16Layout.setVerticalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 33, Short.MAX_VALUE)
        );

        jPanel13.add(jPanel16);

        searchChangePanel.add(jPanel13);

        jPanel2.setLayout(new java.awt.GridLayout(1, 0));

        searchBtn.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        searchBtn.setText("Search");
        jPanel2.add(searchBtn);

        searchChangePanel.add(jPanel2);

        jPanel4.setLayout(new java.awt.GridLayout(1, 0));

        addBtn.setText("Add");
        jPanel4.add(addBtn);

        editBtn.setText("Edit");
        jPanel4.add(editBtn);

        delBtn.setText("Delete");
        jPanel4.add(delBtn);

        searchChangePanel.add(jPanel4);

        leftMainPanel.add(searchChangePanel);

        mainPanel.add(leftMainPanel);

        centerMainPanel.setLayout(new java.awt.GridLayout(1, 0));

        propertyOutList.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        
        jScrollPane2.setViewportView(propertyOutList);

        centerMainPanel.add(jScrollPane2);

        mainPanel.add(centerMainPanel);

        rightMainPanel.setLayout(new java.awt.BorderLayout());

        houseDetailPanel.setLayout(new java.awt.GridLayout(3, 1));

        javax.swing.GroupLayout imgOutLayout = new javax.swing.GroupLayout(imgOut);
        imgOut.setLayout(imgOutLayout);
        imgOutLayout.setHorizontalGroup(
            imgOutLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 246, Short.MAX_VALUE)
        );
        imgOutLayout.setVerticalGroup(
            imgOutLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 195, Short.MAX_VALUE)
        );

        houseDetailPanel.add(imgOut);

        rightTopOut.setLayout(new java.awt.GridLayout(5, 1));

        jPanel6.setLayout(new java.awt.GridLayout(1, 0));

        jLabel10.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel10.setText("Type");
        jPanel6.add(jLabel10);

        typeOut.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jPanel6.add(typeOut);

        rightTopOut.add(jPanel6);

        jPanel7.setLayout(new java.awt.GridLayout(1, 0));

        jLabel11.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel11.setText("City");
        jPanel7.add(jLabel11);

        cityOut.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jPanel7.add(cityOut);

        rightTopOut.add(jPanel7);

        jPanel8.setLayout(new java.awt.GridLayout(1, 0));

        jLabel12.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel12.setText("Floors");
        jPanel8.add(jLabel12);

        floorOut.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jPanel8.add(floorOut);

        rightTopOut.add(jPanel8);

        jPanel9.setLayout(new java.awt.GridLayout(1, 0));

        jLabel13.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel13.setText("Square Footage");
        jPanel9.add(jLabel13);

        footOut.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jPanel9.add(footOut);

        rightTopOut.add(jPanel9);

        jPanel1.setLayout(new java.awt.GridLayout(1, 2));

        jLabel18.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel18.setText("Bedrooms");
        jPanel1.add(jLabel18);
        bedOut.setFont(new java.awt.Font("Tahoma", 0, 14));
        jPanel1.add(bedOut);

        rightTopOut.add(jPanel1);

        houseDetailPanel.add(rightTopOut);

        rightBottomOut.setLayout(new java.awt.GridLayout(5, 1));

        jPanel12.setLayout(new java.awt.GridLayout(1, 0));

        jLabel14.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel14.setText("Bathrooms");
        jPanel12.add(jLabel14);

        bathOut.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jPanel12.add(bathOut);

        rightBottomOut.add(jPanel12);

        jPanel11.setLayout(new java.awt.GridLayout(1, 0));

        jLabel16.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel16.setText("Agent Name");
        jPanel11.add(jLabel16);

        agentIDOut.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jPanel11.add(agentIDOut);

        rightBottomOut.add(jPanel11);

        jPanel10.setLayout(new java.awt.GridLayout(1, 0));

        jLabel15.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel15.setText("");
        jPanel10.add(jLabel15);

        agentNameOut.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jPanel10.add(agentNameOut);

        rightBottomOut.add(jPanel10);

        jPanel3.setLayout(new java.awt.GridLayout());

        jLabel19.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel19.setText("Listing Date");
        jPanel3.add(jLabel19);
        lDateOut.setFont(new java.awt.Font("Tahoma", 0, 14));
        jPanel3.add(lDateOut);

        rightBottomOut.add(jPanel3);

        jPanel5.setLayout(new java.awt.GridLayout(1, 2));

        jLabel20.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel20.setText("Asking Price");
        jPanel5.add(jLabel20);
        priceOut.setFont(new java.awt.Font("Tahoma", 0, 14));
        jPanel5.add(priceOut);

        rightBottomOut.add(jPanel5);

        houseDetailPanel.add(rightBottomOut);

        rightMainPanel.add(houseDetailPanel, java.awt.BorderLayout.CENTER);

        addressOut.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        addressOut.setText("12345 abc Street");
        addressOutPanel.add(addressOut);

        rightMainPanel.add(addressOutPanel, java.awt.BorderLayout.PAGE_START);

        soldPropPanel.setLayout(new java.awt.GridLayout(1, 0));

        openSoldBtn.setText("Sold");
        soldPropPanel.add(openSoldBtn);

        rightMainPanel.add(soldPropPanel, java.awt.BorderLayout.PAGE_END);

        mainPanel.add(rightMainPanel);
        
        
        

        getContentPane().add(mainPanel);

        pack();
    }
                                            

                     
}

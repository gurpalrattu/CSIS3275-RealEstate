package property;
/**
 *
 * @author Nick
 */
import java.awt.event.*;
import Query.*;
import javax.swing.*;
/**This Class controls the GUI that opens when you click the sold button on the main property page*/
public class SoldPropertyGUIControl extends JFrame implements ActionListener {

	/**This object is used to control the GUI*/
	SoldPropertyGUI sp;
        /**This is used to open the com and tax screen*/
	ComTaxGUIControl ct;
        /**This stores the listing price of the property*/
	double price;
        /**This stores the name of the buying agent*/
	String buyer;
        /**This object is used to do all queries needed for this class*/
        Query q;
        /**This stores the id of the listing agent*/
        int agentid;
        /**This stores the address of the house and the name of the listing agent*/
	String address, agent;
        /**This is used to redo the search after a property is sold*/
        PropertyMainGUIControl pmc;
        /**This constructor is used to set up the sold property GUI and add the  action listeners*/
	public SoldPropertyGUIControl(String title,String price, String agent, int agentid, String address, PropertyMainGUIControl pmc){
                q = new Query();
                this.agentid = agentid;
                this.address = address;
                this.agent = agent;
                this.pmc = pmc;
		sp  = new SoldPropertyGUI(title,q.getAgent());
		sp.setVisible(true);
		sp.setLocationRelativeTo(null);
		sp.jLabel4.setText(price);
                sp.jLabel5.setText(agent);
		addListener();
	}
	/**This method adds the listener to the sold entry button*/
	private void addListener(){
		sp.soldEntry.addActionListener(this);
	}	
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == sp.soldEntry){			
			String errMes = "";
			boolean err = false;
			//these ifs are used to ensure that the user inputs a price and agent
			if(sp.priceEntry.getText().length() == 0){
				errMes += "The Price Entry Is Invalid" + '\n';
				err = true;
			}
			else{
				try {
					price = Double.valueOf(sp.priceEntry.getText());					
				} catch (Exception e2) {
					errMes += "The Price Entry Is Invalid" + '\n';
					err = true;
				}
			}
                        //these ifs are used to ensure that the user inputs a price and agent
			if(sp.buyerEntry.getSelectedIndex() == 0){
				errMes += "The Buyer Entry Is Invalid" + '\n';
				err = true;
			}
			//sends the data taken to the confirm screen where it will be sent to the database if they confirm
			if(!err){
				ct = new ComTaxGUIControl("Confrim",price,String.valueOf(sp.buyerEntry.getSelectedItem()),q.getAgentID(agent), address, sp, pmc);
                                sp.setVisible(false);

			}
			//This is if the user did not enter the data correctly
			else{				
				JOptionPane.showMessageDialog(null, errMes, "Error", JOptionPane.ERROR_MESSAGE);				
			}			
		}
	}
}

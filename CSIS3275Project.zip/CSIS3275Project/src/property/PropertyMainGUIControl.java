package property;
/**
 *
 * @author Nick
 */
import Query.Query;
import java.awt.event.*;
import java.text.*;
import java.util.*;
import javax.swing.*;
import javax.swing.event.*;
/**This Class is the main class for the Property it is the hub for the add edit and delete properties and the way to sell a property*/
public class PropertyMainGUIControl extends JFrame implements ActionListener, ListSelectionListener {
	
	/**This object is used to open the add edit or delete GUIs*/
	PropertyChangeGUIControl pcg;
        /**This object is used to open and use the main property GUI*/
	PropertyMainGUI pm;
        /**This object is used to go to the sold property GUI*/
	SoldPropertyGUIControl sp;
        /**This boolean is used to hide things from people without manager access*/
	boolean isManager;
        /**This object is used to access all the queries in the query class*/
        Query q = new Query();
        /**This format is used to output a $ value*/
        NumberFormat dollarFormat = NumberFormat.getCurrencyInstance();
        /**This constructor sets up the main property GUI and add the action listeners*/
	public PropertyMainGUIControl(boolean isManager) {
		this.isManager = isManager;
		pm = new PropertyMainGUI(q.getType(),q.getCity(),q.getAgent());               
		pm.setVisible(true);
		pm.setLocationRelativeTo(null);
                pm.setDefaultCloseOperation(HIDE_ON_CLOSE);
                displaySelectedProp(null);
		//this if sets panels invisible to users without the privileges to see them
                if(!isManager){			
			pm.addBtn.setVisible(false);
			pm.editBtn.setVisible(false);
			pm.delBtn.setVisible(false);
			pm.openSoldBtn.setVisible(false);
		}		
		addListeners();
		
		
	}
	
	/**This method adds the listeners to the components needed for user interaction*/
	private void addListeners(){
		pm.addBtn.addActionListener(this);
		pm.editBtn.addActionListener(this);
		pm.delBtn.addActionListener(this);
		pm.searchBtn.addActionListener(this);
		pm.agentEntry.addActionListener(this);
		pm.typeEntry.addActionListener(this);
		pm.cityEntry.addActionListener(this);
		pm.isSoldRBtn.addActionListener(this);
		pm.openSoldBtn.addActionListener(this);	
                pm.propertyOutList.addListSelectionListener(this);
		//this clears the date entry when clicked
		pm.dateEntry.addMouseListener(new MouseAdapter(){
        @Override
        public void mouseClicked(MouseEvent e){
            pm.dateEntry.setText("");
        }
		});	
	}	
	/**This method is used when an item is clicked on the property out list which then calls the display selected method*/
	@Override
	public void valueChanged(ListSelectionEvent e) {
		if(e.getSource() == pm.propertyOutList){
			if(pm.propertyOutList.getSelectedIndex() > -1){							
				displaySelectedProp(String.valueOf(pm.propertyOutList.getSelectedValue()));	
			}
                        else{
                            displaySelectedProp("");
                        }
		}				
	}
	/**This method is used to call the query class to populate the output on the right hand side of the screen*/
	public void displaySelectedProp(String selected){		
		if(selected == ""){
			pm.addressOut.setText(null);
			pm.typeOut.setText(null);
			pm.cityOut.setText(null);
			pm.floorOut.setText(null);
			pm.footOut.setText(null);
			pm.bedOut.setText(null);
			pm.bathOut.setText(null);
			pm.agentIDOut.setText(null);
			pm.agentNameOut.setText(null);
			pm.lDateOut.setText(null);
			pm.priceOut.setText(null);
		}
		else{
			String values[] = new String[11];
                        values = q.getDisplay(selected);
			pm.addressOut.setText(values[0]);
			pm.typeOut.setText(values[1]);
			pm.cityOut.setText(values[2]);
			pm.floorOut.setText(values[3]);
			pm.footOut.setText(values[4]);
			pm.bedOut.setText(values[5]);
			pm.bathOut.setText(values[6]);
			pm.agentIDOut.setText(values[7]);
			pm.lDateOut.setText(values[8]);			
                        try{
                            pm.priceOut.setText(dollarFormat.format(Double.valueOf(values[9])));
                        if(values[10].charAt(0) == 't'){
                            pm.openSoldBtn.setVisible(false);
                        }
                        else{
                             pm.openSoldBtn.setVisible(true);
                        }
                        }
                        catch(Exception e){
                            System.out.println(e);
                        }
		}
	}
	/**this method deals with all action listeners*/	
	public void actionPerformed(ActionEvent e) {
		//if the action was the search button
		if(e.getSource() == pm.searchBtn){			
				search();
		}//if the action was the search button
		/////////////////////////////////////////////////
		//if the action was the add button
		else if(e.getSource() == pm.addBtn){
			System.out.println("add button");
			pcg = new PropertyChangeGUIControl("Add Property", "", this, q.getAgent());
			pm.propertyOutList.clearSelection();
		}//if the action was the add button
		/////////////////////////////////////////////////
		//if the action was the edit button
		else if(e.getSource() == pm.editBtn){
			System.out.println("edit button");
			if(pm.propertyOutList.getSelectedIndex() > -1){
				pcg = new PropertyChangeGUIControl("Edit Property", String.valueOf(pm.propertyOutList.getSelectedValue()), this, q.getAgent());
				pm.propertyOutList.clearSelection();
			}			
		}//if the action was the edit button
		/////////////////////////////////////////////////
		//if the action was the delete button
		else if(e.getSource() == pm.delBtn){
			System.out.println("delete button");
			if(pm.propertyOutList.getSelectedIndex() > -1){
				pcg = new PropertyChangeGUIControl("Delete Property", String.valueOf(pm.propertyOutList.getSelectedValue()), this, q.getAgent());
				pm.propertyOutList.clearSelection();
			}			
		}//if the action was the delete button
		/////////////////////////////////////////////////
		//if the action was the open sold panel button
		else if(e.getSource() == pm.openSoldBtn){
			
			
			sp = new SoldPropertyGUIControl("Final Sale",pm.priceOut.getText(),pm.agentIDOut.getText(), q.getAgentID(pm.agentIDOut.getText()),pm.addressOut.getText(),this);
		}
		//if the action was the open sold panel button
	}//end of the action performed method	
	/**this method deals with searching for property IDs that meet all required search fields*/
	public void search(){
		/**sets the max and min price decimals to a max of 2 points*/
		DecimalFormat twoD = new DecimalFormat("#.00");		
		/**this is to save the type of building input by the user*/
		String type = "";
		/**this is to save the city input by the user*/
		String city = "";
		/**this is to save the agent selected by the user*/
		String agent = "";
		/**this is to save the minimum price input by the user*/
		double min = 0;
		/**this is to save the max price input by the user*/
		double max = 0;
		/**this is to save the bathroom amount input by the user*/
		int bath = 0;
		/**this is to save the half bathroom amount input by the user*/
		int halfBath = 0;
		/**this is to save the bedroom amount input by the user*/
		int bed = 0;
		/**this is to save the square footage input by the user*/
		int foot = 0;
		/**this is to save the floor input by the user*/
		int floor = 0;
		/**this is to save the date input by the user*/
                java.sql.Date date;
		/**this is the vector that will be used for sending to the query class to get property ids*/			
		Vector sendVT = new Vector();
		/**this is the message that will be displayed to the user if there are any errors*/
		String errorMessage = "";
		/**if there are any errors in data entry this becomes true and stops the program from moving onto the search phase*/
		boolean error = false;
		//lines of if statements for all the possible entries to be searched
		//all entries have their own try catch, if nessecary,  which adds error messages to display to the user 
		//if there is a problem with their entry
		if(pm.typeEntry.getSelectedItem().toString().length() != 0){
			type = pm.typeEntry.getSelectedItem().toString();
			sendVT.add(type);
		}
                else{
                    sendVT.add("");
                }
		if(pm.cityEntry.getSelectedItem().toString().length() != 0){
			city = pm.cityEntry.getSelectedItem().toString();
			sendVT.add(city);
		}
                else{
                    sendVT.add("");
                }
		if(pm.minPEntry.getText().length() != 0){
			try {
				min = Double.valueOf(twoD.format(Double.valueOf(pm.minPEntry.getText())));
				sendVT.add(min);
			} catch (Exception err) {
				errorMessage += "Minimum Price Entry Invalid" + '\n';
				error = true;
			}				
		}
                else{
                    sendVT.add("");
                }
		if(pm.maxPEntry.getText().length() != 0){
			try {
				max = Double.valueOf(twoD.format(Double.valueOf(pm.maxPEntry.getText())));
				sendVT.add(max);
			} catch (Exception err) {
				errorMessage += "Maximum Price Entry Invalid" + '\n';
			}
		}
                else{
                    sendVT.add("");
                }
		if(pm.bathEntry.getText().length() != 0){
			try {
				bath = Integer.valueOf(pm.bathEntry.getText());
				sendVT.add(bath);
			} catch (Exception err) {
				errorMessage += "Bathroom Entry Amount Invalid" + '\n';
				error = true;
			}
		}
                else{
                    sendVT.add("");
                }
		if(pm.halfBathEntry.getText().length() != 0){
			try {
				halfBath = Integer.valueOf(pm.halfBathEntry.getText());
				sendVT.add(halfBath);
			} catch (Exception err) {
				errorMessage += "Halfbath Entry Amount Invalid" + '\n';
				error = true;
			}
		}
                else{
                    sendVT.add("");
                }
		if(pm.bedEntry.getText().length() != 0){
			try {
				bed = Integer.valueOf(pm.bedEntry.getText());
				sendVT.add(bed);
			} catch (Exception err) {
				errorMessage += "Bedroom Entry Invalid" + '\n';
				error = true;
			}
		}
                else{
                    sendVT.add("");
                }
		//this might get changed but for now this is how I check that the date has been entered correctly
		//the compare to checks that the user has tried to enter something and has not just left 
		//the entry to the default of mm dd yyyy
		if(pm.dateEntry.getText().length() != 0 && pm.dateEntry.getText().charAt(0) != 'Y'){
			try {
				
                                               
                        date = java.sql.Date.valueOf(pm.dateEntry.getText());
                              
                        sendVT.add(date);
                        
			} catch (Exception e1) {
				errorMessage += "Date Entry Invalid Format Must Be YYYY-MM-DD" + '\n';
				error = true;
                                System.out.println(e1);
                                
                                
			}
                        
                        //java.sql.Timestamp c = new java.sql.Timestamp(now.getTime()); 
		}
                else{
                    sendVT.add("");
                }
		if(pm.agentEntry.getSelectedItem().toString().length() != 0){
			agent = pm.agentEntry.getSelectedItem().toString();
			sendVT.add(pm.agentEntry.getSelectedIndex());
		}
                else{
                    sendVT.add("");
                }
		if(pm.sqrFootEntry.getText().length() != 0){
			try {
				foot = Integer.valueOf(pm.sqrFootEntry.getText());
				sendVT.add(foot);
			} catch (Exception err) {
				errorMessage += "Square Foot Entry Invalid" + '\n';
				error = true;
			}
		}
                else{
                    sendVT.add("");
                }
		if(pm.floorEntry.getText().length() != 0){
			try {
				floor = Integer.valueOf(pm.floorEntry.getText());
				sendVT.add(floor);
			} catch (Exception err) {
				errorMessage += "Floor Entry Invalid" + '\n';
				error = true;
			}
		}
                else{
                    sendVT.add("");
                }
                if(pm.isSoldRBtn.isSelected()){
                    sendVT.add("true");
                }
                else{
                    sendVT.add("false");
                }
		//last line of entry checking before the error if else
		
		if(error){
			JOptionPane.showMessageDialog(null, errorMessage , "Error", JOptionPane.ERROR_MESSAGE);
		}//if error
		//if there was no error in any entry field then we move onto this else
		else{
			Vector p = new Vector();
                        p = q.propertyOut(sendVT);
                        pm.propertyOutList.setListData(p);
		}//else to go with error if
	}
}
package property;
/**
 *
 * @author Nick
 */
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.NumberFormat;
import Query.*;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
/**This Class is used to control the final screen that opens in a sale of a house*/
public class ComTaxGUIControl extends JFrame implements ActionListener{
        /**This object is used to do all the queries*/
	Query q;
        /**This object is used to create the GUI*/
	ComTaxGUI ct;
        /**These store the values for the property price the tax and the com*/
	double price,tax,com;
        /**This is used to display the output in $*/
	NumberFormat dollarFormat = NumberFormat.getCurrencyInstance();
        /**This stores the id of the listing agent*/
        int sAgent;
        /**This stores the address and the buying agents name*/
        String selected, bAgent;
        /**This is used to make the sold property GUI visible if the user does not hit confirm*/
        SoldPropertyGUI sp;
        /**This is used to redo the search after a property is sold*/
        PropertyMainGUIControl pmc;
	/**This Class is used to control and generate the tax and com GUI*/
	public ComTaxGUIControl(String title, double price, String bAgent, int sAgent,  String selected, SoldPropertyGUI sp,PropertyMainGUIControl pmc){
		q = new Query();
		this.price = price;
                this.bAgent = bAgent;
                this.sAgent = sAgent;
                this.selected = selected;
                this.sp = sp;
                this.pmc = pmc;
		ct = new ComTaxGUI(title);
		ct.setVisible(true);
		ct.setLocationRelativeTo(null);
		
		calculate();
		
		addListeners();
		
		
	}
	
	private void addListeners(){
		ct.confirm.addActionListener(this);
		ct.cancel.addActionListener(this);
	}
	/**calculates and displays the tax and commission*/
	private void calculate(){
		tax = price * .05;		
		if(price > 100000){
			com = 100000 * .07;
			price -= 100000;			
			com += price * .03;			
		}
		else{
			com = price * .07;
		}
		ct.com.setText(String.valueOf(dollarFormat.format(com)));
		ct.tax.setText(String.valueOf(dollarFormat.format(tax)));
	}
	public void actionPerformed(ActionEvent e) {		
            int dialogResult;
            boolean confirm = true;            
            if(e.getSource() == ct.confirm){
			dialogResult = JOptionPane.showConfirmDialog(this, "Are You Sure Your Entries Are Corect", "Warning Sale Eminent", JOptionPane.YES_NO_OPTION);
					if(dialogResult == 0) {
                                                q.markSold(tax, com, sAgent, bAgent, price, q.getHouseID(selected));
						System.out.println("SOLD");
                                                pmc.search();
					}
					else{
						confirm = false;
					}
                                        if(confirm){
                                            ct.setVisible(false);
                                        }
		}
		else if(e.getSource() == ct.cancel){
			ct.setVisible(false);
                        sp.setVisible(true);
		}
	}
}

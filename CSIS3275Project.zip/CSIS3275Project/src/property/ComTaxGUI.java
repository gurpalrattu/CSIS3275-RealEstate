package property;
/**
 *
 * @author Nick
 */
import javax.swing.*;


public class ComTaxGUI extends JFrame {

    /**
     * Creates new form ComTaxGUI
     */
    public ComTaxGUI(String title) {
    	super(title);
        initComponents();
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">                          
    public void initComponents() {

        jPanel2 = new JPanel();
        jLabel2 = new JLabel();
        jPanel3 = new JPanel();
        com = new JLabel();
        jPanel4 = new JPanel();
        jLabel1 = new JLabel();
        jPanel7 = new JPanel();
        tax = new JLabel();
        jPanel6 = new JPanel();
        confirm = new JButton();
        jPanel5 = new JPanel();
        cancel = new JButton();

        setDefaultCloseOperation(WindowConstants.HIDE_ON_CLOSE);
        getContentPane().setLayout(new java.awt.GridLayout(3, 2));

        jPanel2.setLayout(new java.awt.GridLayout());

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel2.setText("Commision");
        jPanel2.add(jLabel2);

        getContentPane().add(jPanel2);

        jPanel3.setLayout(new java.awt.GridLayout());
        jPanel3.add(com);

        getContentPane().add(jPanel3);

        jPanel4.setLayout(new java.awt.GridLayout(1, 1));

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel1.setText("Tax");
        jPanel4.add(jLabel1);

        getContentPane().add(jPanel4);

        jPanel7.setLayout(new java.awt.GridLayout());
        jPanel7.add(tax);

        getContentPane().add(jPanel7);

        confirm.setText("Confirm");
        jPanel6.add(confirm);

        getContentPane().add(jPanel6);

        cancel.setText("Cancel");
        jPanel5.add(cancel);

        getContentPane().add(jPanel5);

        pack();
    }// </editor-fold>                        


    // Variables declaration - do not modify                     
    public JButton cancel;
    public JButton confirm;
    public JLabel jLabel1;
    public JLabel jLabel2;
    public JPanel jPanel2;
    public JPanel jPanel3;
    public JPanel jPanel4;
    public JPanel jPanel5;
    public JPanel jPanel6;
    public JPanel jPanel7;
    public JLabel com;
    public JLabel tax;
    // End of variables declaration                   
}

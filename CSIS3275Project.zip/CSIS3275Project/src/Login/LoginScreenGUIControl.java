package Login;
 /**
 *
 * @author Nick
 */
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import MainScreen.*;
/**This class is used to open the Login GUI and manages the password and username entry*/
public class LoginScreenGUIControl extends JFrame implements ActionListener{
    //These are temp user names and password just for the demo
    String usr[] = {"man", "sale"};
    String pass[] = {"123", "321"};
    /**This object creates the Login GUI*/
    LoginScreenGUI l;
    /**This object creates the main screen*/
    MainGUIControl m;
    /**This constructor makes the login GUI appear*/
    public LoginScreenGUIControl(){        
        l = new LoginScreenGUI();        
        l.setVisible(true);
        l.setLocationRelativeTo(null);       
        l.login.addActionListener(this);
    }
    /**This is a temp way to demonstrate the login with username and password*/
    public void actionPerformed(ActionEvent e) {
		if(e.getSource() == l.login){                    
                    String password = String.valueOf(l.pass.getPassword());
                    if(l.usr.getText().compareTo(usr[0]) == 0){
                         if(password.compareTo(pass[0]) == 0){
                                m = new MainGUIControl(true);
                                l.setVisible(false);
                    }
                    }
                    else if(l.usr.getText().compareTo(usr[1]) == 0){
                         if(password.compareTo(pass[1]) == 0){
                                m = new MainGUIControl(false);
                                l.setVisible(false);
                    }
                    }
                    else{
                        JOptionPane.showMessageDialog(null, "Incorrect User Or Password" , "Error", JOptionPane.ERROR_MESSAGE);
                    }
		}
	}
}

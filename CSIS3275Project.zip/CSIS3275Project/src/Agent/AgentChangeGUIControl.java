package Agent;
/**
 *
 * @author Nick
 */
import Query.Query;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import property.*;
/**This Class handeles the changes made to the agent database*/
public class AgentChangeGUIControl extends JFrame implements ActionListener{
    /**This object is used to create the Change GUI*/
    AgentChangeGUI a;
    /**This object is used to make all queries*/
    Query q;
    /**This is used to check which type of change is requested by the main agent GUI*/
    String title;
    /**This is the selected agent id*/
    int selected;
    /**This constructor sets up the GUI*/
    public AgentChangeGUIControl(String title,int selected){
        this.title = title;
        this.selected = selected;
        a = new AgentChangeGUI(title);
        a.setVisible(true);
        a.setLocationRelativeTo(null);
        q = new Query();        
        addListeners();
        /**This fills the fields of the GUI if the user is not adding an agent*/
        if(title != "Add"){
            setValues(q.getAgentDetail(selected));
        }
    }
    //This method adds listeners to the two buttons
    public void addListeners(){
        a.confirm.addActionListener(this);
        a.cancel.addActionListener(this);
    }
    //This method takes the vaclues from the query and adds them to the GUI 
    public void setValues(String val[]){        
        a.name.setText(val[0]);
        a.phone.setText(val[1]);
        a.age.setText(val[2]);
        a.pass.setText(val[3]);       
        if(val[4].charAt(0) == 'M'){
            a.manager.setSelected(true);
        }
        else{
            a.manager.setSelected(false);
        }
    }
        public void actionPerformed(ActionEvent e) {
            if(e.getSource() == a.confirm){
		//This is used to check if the user confirms or cancels their changes	
                int dialogResult;
                //This is used to check if the user confirms or cancels their changes
                boolean confirm = true;                
                switch(title){
                            case "Add":
                                dialogResult = JOptionPane.showConfirmDialog(this, "Are You Sure You Wish To Add This Agent?", "Warning Addition Eminent", JOptionPane.YES_NO_OPTION);
					if(dialogResult == 0) {
						q.addAgent(getInput());
						System.out.println("Added");
					}
					else{
						confirm = false;
					}
                            break;
                            case "Edit":
                                dialogResult = JOptionPane.showConfirmDialog(this, "Are You Sure You Wish To Edit Agent ID " + selected, "Warning Edit Eminent", JOptionPane.YES_NO_OPTION);
					if(dialogResult == 0) {
                                                q.editAgent(getInput(),selected);
						System.out.println("Edited");
					}
					else{
						confirm = false;
					}
                            break;
                            case "Delete":
                                dialogResult = JOptionPane.showConfirmDialog(this, "Are You Sure You Wish To Delete The Agent With " + selected + " As The ID", "Warning Deletion Eminent", JOptionPane.YES_NO_OPTION);
					if(dialogResult == 0) {
						q.deleteAgent(selected);
						System.out.println("Deleted");
					}
					else{
						confirm = false;
					}
                            break;
                        }
                if(confirm){
                    a.setVisible(false);
                }
		}
		else if(e.getSource() == a.cancel){
			a.setVisible(false);
		}
	}
    //This method gets the values in the entry fields
    public String[] getInput(){        
        String vals[] = new String[5];        
        vals[0] = a.name.getText();
        vals[1] = a.phone.getText();
        vals[2] = a.age.getText();
        vals[3] = a.pass.getText();
        if(a.manager.isSelected()){
            vals[4] = "Manager";
        }
        else{
            vals[4] = "Agent";
        }
        return vals;
    }    
}
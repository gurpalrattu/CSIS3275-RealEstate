package Agent;
/**
 *
 * @author Nick
 */
import Query.Query;
import property.*;
import javax.swing.*;
import java.awt.event.*;
/**This class is a screen where the user can select if they want to add edit or delete agents*/
public class AgentMainGUIControl extends JFrame implements ActionListener{
    /**This object is used to create the Main GUI*/
    AgentMainGUI a;
    /**This is used to do any queries*/
    Query q;
    /**This is used to open the change GUI*/
    AgentChangeGUIControl ac;
    /**This constructor creates the GUI and adds the listeners*/
    public AgentMainGUIControl(){
        q = new Query();
        a = new AgentMainGUI(q.getAgent());
        a.setVisible(true);
        a.setLocationRelativeTo(null);
        addListeners();
    }
    /**This method adds the listeners to the three buttons*/
    public void addListeners(){
        a.add.addActionListener(this);
        a.edit.addActionListener(this);
        a.delete.addActionListener(this);
    }
       public void actionPerformed(ActionEvent e) {
	if(e.getSource() == a.add){
            ac = new AgentChangeGUIControl("Add",a.agent.getSelectedIndex());
            a.setVisible(false);
            
        }
        else if(e.getSource() == a.edit && a.agent.getSelectedIndex() != 0){
            ac = new AgentChangeGUIControl("Edit",a.agent.getSelectedIndex());
            a.setVisible(false);
        }
        else if(e.getSource() == a.delete && a.agent.getSelectedIndex() != 0){
            ac = new AgentChangeGUIControl("Delete",a.agent.getSelectedIndex());
            a.setVisible(false);
        }     
    }
}

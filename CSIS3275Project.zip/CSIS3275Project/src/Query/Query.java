package Query;
/**
 *
 * @author Nick
 */
import java.sql.*;
import java.util.*;
/**This Class preforms all the Queries*/
public class Query {
    
      /**This method is used to populate the right side of the main property screen
     * it takes in a address and returns all the details required for the display*/
    public String[] getDisplay(String address){
        String[] output = new String[11];        
        String dbURL = "jdbc:derby://localhost:1527/RealEstateDB";
		String user = "NewWestSolutions";
		String pass = "newwest";        
        //this creates the sql statement
        String sql = "SELECT * FROM HOUSE_TABLE AS h  " ;
        sql += "INNER JOIN AGENT_TABLE AS a on a.AGENTID = h.AGENTID WHERE HOUSEADDRESS = \'" + address + "\'";
        System.out.println(address);
        try {
                // set up the connection to the DB
                Connection myConn = DriverManager.getConnection(dbURL, user, pass);                
                // this allows you to make even send a statement to the DB
                try {
		Statement myStmt = myConn.createStatement();		              
                ////////// this is for the select statement
		  try {
		ResultSet myRs = myStmt.executeQuery(sql);
		//this while generates the output from the database
			while (myRs.next()) {
                        output[0] = myRs.getString("houseaddress");
                        output[1] = myRs.getString("propertytype");
			output[2] = myRs.getString("city");
                        output[3] = myRs.getString("levels");
                        output[4] = myRs.getString("lotsize");
                        output[5] = myRs.getString("numbedroom");
                        output[6] = myRs.getString("numfullbathroom");
                        output[7] = myRs.getString("agentname");
                        output[8] = myRs.getString("dateoflisting");
                        output[9] = myRs.getString("price");
                        output[10] = myRs.getString("sold");
		}
            } 
		catch (Exception e)
		{
			System.out.println(e);
		} 
		}
		catch (Exception e)
		{
			System.out.println("Error connecting to database");
		}                
                // have to close the connection to the database at the end of the query
                 myConn.close();
}
		catch (Exception e)
		{
			System.out.println(e);
		}
      return output;  
    }  
    /**This method gets all the types that are currently in the database*/
    public String[] getType(){
      String[] type;
      Vector temp = new Vector();      
      String dbURL = "jdbc:derby://localhost:1527/RealEstateDB";
		String user = "NewWestSolutions";
		String pass = "newwest";        
        //this is the sql statement that tells the database what we need from it
        String sql = "SELECT DISTINCT propertytype FROM HOUSE_TABLE";        
        try {
                // set up the connection to the DB
                Connection myConn = DriverManager.getConnection(dbURL, user, pass);                
                // this allows you to make even send a statement to the DB
                try {
		Statement myStmt = myConn.createStatement();		              
                ////////// this is for the select statement
		  try {
		ResultSet myRs = myStmt.executeQuery(sql);		
			while (myRs.next()) {
                        temp.add(myRs.getString("propertytype"));                                                                    
		}
            } 
		catch (Exception e)
		{
			System.out.println(e);
		} 
		}
		catch (Exception e)
		{
			System.out.println("Error connecting to database");
		}                
                // have to close the connection to the database at the end of the query
                 myConn.close();}
		catch (Exception e)
		{
			System.out.println(e);
		}      
      type = new String[temp.size()+1];
      type[0] = "";
      //I convert it from a Vector to a string[] here just for convenience
      for(int i = 0; i < temp.size(); i ++){
          type[i+1] = String.valueOf(temp.elementAt(i));
      }
      return type;  
    }
    /**This method gets the cities currently in the database*/
    public String[] getCity(){
        String[] city;
      Vector temp = new Vector();      
      String dbURL = "jdbc:derby://localhost:1527/RealEstateDB";
		String user = "NewWestSolutions";
		String pass = "newwest";        
        //this is the sql statement that is used to get all the citeis fromt he database
        String sql = "SELECT DISTINCT city FROM HOUSE_TABLE";        
        try {
                // set up the connection to the DB
                Connection myConn = DriverManager.getConnection(dbURL, user, pass);                
                // this allows you to make even send a statement to the DB
                try {
		Statement myStmt = myConn.createStatement();		              
                ////////// this is for the select statement
		  try {
		ResultSet myRs = myStmt.executeQuery(sql);		
		while (myRs.next()) {
                        temp.add(myRs.getString("city"));                                                                    
		}
            } 
		catch (Exception e)
		{
			System.out.println(e);
		} 
		}
		catch (Exception e)
		{
			System.out.println("Error connecting to database");
		}                
                // have to close the connection to the database at the end of the query
                 myConn.close();
}
		catch (Exception e)
		{
			System.out.println(e);
		}      
      city = new String[temp.size()+1];
      city[0] = "";
      //I convert it from a Vector to a string[] here just for convenience
      for(int i = 0; i < temp.size(); i ++){
          city[i+1] = String.valueOf(temp.elementAt(i));
      }        
      return city;
    }
    /**This method gets the agent names to be selected from later*/
    public String[] getAgent(){
      String[] agentname;
      Vector temp = new Vector();
      String dbURL = "jdbc:derby://localhost:1527/RealEstateDB";
		String user = "NewWestSolutions";
		String pass = "newwest";        
        String sql = "SELECT DISTINCT agentname FROM AGENT_TABLE";        
        try {
                // set up the connection to the DB
                Connection myConn = DriverManager.getConnection(dbURL, user, pass);                
                // this allows you to make even send a statement to the DB
                try {
		Statement myStmt = myConn.createStatement();		              
                ////////// this is for the select statement
		  try {
		ResultSet myRs = myStmt.executeQuery(sql);		
			while (myRs.next()) {
                        temp.add(myRs.getString("agentname"));                                                                    
		}
            } 
		catch (Exception e)
		{
			System.out.println(e);
		} 
		}
		catch (Exception e)
		{
			System.out.println("Error connecting to database");
		}                
                // have to close the connection to the database at the end of the query
                 myConn.close();}
		catch (Exception e)
		{
			System.out.println(e);
		}
      agentname = new String[temp.size() + 1];
      agentname[0] = "";      
      //I convert it from a Vector to a string[] here just for convenience
      for(int i = 0; i < temp.size(); i ++){
          agentname[i + 1] = String.valueOf(temp.elementAt(i));
      }      
      return agentname;  
    }   
    /**This method is used to get the property addresses that result from the search*/
    public Vector propertyOut(Vector recieved){        
        Vector sendVT = new Vector();        
        String[] search = new String[recieved.size()];        
        for(int x = 0; x < search.length; x++){
              search[x] = String.valueOf(recieved.elementAt(x));
        }
        String dbURL = "jdbc:derby://localhost:1527/RealEstateDB";
		String user = "NewWestSolutions";
		String pass = "newwest";                      
                String db[] = new String[12];
                //this is how the sql statement is created
                String sql = "";  
                boolean count = false;
                try{
                db[0] = "propertytype"; 
                if(search[0].length() != 0){                    
                    sql += "\'" + search[0] + "\' = " +  db[0]; 
                    count = true;                   
                }                            
                db[1] = "city"; 
                if(search[1].length() != 0){ 
                    if(count){
                    sql += " AND ";
                }
                    sql += "\'" + search[1] + "\' = " +  db[1];             
                    count = true;                   
                }
                db[2] = "price"; 
                if(search[2].length() != 0){  
                     if(count){
                    sql += " AND ";
                }
                    sql += search[2] + " < " +  db[2];             
                    count = true;                   
                }
                db[3] = "price";
                if(search[3].length() != 0){  
                    if(count){
                    sql += " AND ";
                }
                    sql += search[3] + " > " +  db[3];             
                    count = true;                   
                }
                db[4] = "numfullbathroom"; 
                if(search[4].length() != 0){  
                    if(count){
                    sql += " AND ";
                }
                    sql += search[4] + " <= " +  db[4];             
                    count = true;                   
                }
                db[5] = "numbathroomhalf"; 
                if(search[5].length() != 0){   
                     if(count){
                    sql += " AND ";
                }
                    sql += search[5] + " <= " +  db[5];             
                    count = true;                   
                }
                db[6] = "numbedrooom"; 
                if(search[6].length() != 0){  
                    if(count){
                    sql += " AND ";
                }
                    sql += search[6] + " <= " +  db[6];             
                    count = true;                   
                }
                db[7] = "dateoflisting";  
                if(search[7].length() != 0){
                    if(count){
                    sql += " AND ";
                }
                    sql += "\'" + search[7] + "\' <= " +  db[7];             
                    count = true;                   
                }
                db[8] = "agentid"; 
                if(search[8].length() != 0){ 
                    if(count){
                    sql += " AND ";
                }
                    sql += search[8] + " = " +  db[8];             
                    count = true;                   
                }
                db[9] = "lotsize";
                if(search[9].length() != 0){  
                    if(count){
                    sql += " AND ";
                }
                    sql += search[9] + " <= " +  db[9];             
                    count = true;                   
                }
                db[10] = "levels";
                if(search[10].length() != 0){ 
                    if(count){
                    sql += " AND ";
                }
                    sql += search[10] + " <= " +  db[10];             
                    count = true;                   
                }
                db[11]  = "sold";
                if(search[11].length() != 0){ 
                    if(count){
                    sql += " AND ";
                }
                    sql += search[11] + " = " +  db[11];             
                    count = true;                   
                }
                if(count){
                    String temp = sql;
                    sql = "SELECT * FROM HOUSE_TABLE WHERE " + temp;
                }
                else{
                   sql = "SELECT * FROM HOUSE_TABLE"; 
                }
                }
                catch(Exception e){
                    
                }
        try {
                // set up the connection to the DB
                Connection myConn = DriverManager.getConnection(dbURL, user, pass);
                // this allows you to make even send a statement to the DB
                try {
		Statement myStmt = myConn.createStatement();
                ////////// this is for the select statement
		  try {
		ResultSet myRs = myStmt.executeQuery(sql);
			while (myRs.next()) {
                        sendVT.add(myRs.getString("houseaddress"));
		}
            } 
		catch (Exception e)
		{
			System.out.println(e);
		} 
		}
		catch (Exception e)
		{
			System.out.println("Error connecting to database");
		}                
                // have to close the connection to the database at the end of the query
                 myConn.close();}
		catch (Exception e)
		{
			System.out.println(e);
		}
        System.out.println(sql);         
        return sendVT;
    }
    /**This method is how properties are added into the database*/
    public void addProperty(String address, String type, String city, String agent, String bed, String halfbath, String bath, String floor, String footage, String price){
      // 1) create a java calendar instance
        Calendar calendar = Calendar.getInstance(); 
        // 2) get a java.util.Date from the calendar instance.
        //    this date will represent the current instant, or "now".
        java.util.Date now = calendar.getTime();
        // 3) a java current time (now) instance
        java.sql.Timestamp c = new java.sql.Timestamp(now.getTime());                 
      String dbURL = "jdbc:derby://localhost:1527/RealEstateDB";
		String user = "NewWestSolutions";
		String pass = "newwest";     
        String sql = "INSERT INTO HOUSE_TABLE (HOUSEADDRESS, PROPERTYTYPE, CITY, AGENTID, NUMBEDROOM, NUMBATHROOMHALF, NUMFULLBATHROOM, LEVELS, LOTSIZE, PRICE, SOLD, DATEOFLISTING)";
        sql += "VALUES (\'" + address + "\',\'" + type + "\',\'" + city  + "\'," + agent  + "," + bed  + "," + halfbath  + "," + bath  + "," + floor  + ",\'" + footage  + "\'," + price + ", false, \'" + c + "\')";       
        try {
                // set up the connection to the DB
                Connection myConn = DriverManager.getConnection(dbURL, user, pass);                
                // this allows you to make even send a statement to the DB
                try {
		Statement myStmt = myConn.createStatement();		              
                ////////// this is for the select statement
		  try {
		myStmt.executeUpdate(sql);
            } 
		catch (Exception e)
		{
			System.out.println(e);
		} 
		}
		catch (Exception e)
		{
			System.out.println("Error connecting to database");
		}
                // have to close the connection to the database at the end of the query
                 myConn.close();}
		catch (Exception e)
		{
			System.out.println(e);
		}     
      System.out.println(sql);
     
    }
    /**This method is how properties in the database are edited*/
    public void editProperty(String selected, String address, String type, String city, String agent, String bed, String halfbath, String bath, String floor, String footage, String price){
        String dbURL = "jdbc:derby://localhost:1527/RealEstateDB";
		String user = "NewWestSolutions";
		String pass = "newwest";     
        String sql = "UPDATE HOUSE_TABLE SET ";
        sql += "HOUSEADDRESS = \'" + address + "\', PROPERTYTYPE = \'" + type + "\', CITY = \'" + city;
        sql += "\', AGENTID = " + agent + ", NUMBEDROOM = " + bed + ", NUMBATHROOMHALF = " + halfbath;
        sql += ", NUMFULLBATHROOM = " + bath + ", LEVELS = " + floor + ", LOTSIZE = \'" + footage + "\', PRICE = " + price; 
        sql += " WHERE HOUSEADDRESS = \'" + selected + "\'";         
        try {
                // set up the connection to the DB
                Connection myConn = DriverManager.getConnection(dbURL, user, pass);                
                // this allows you to make even send a statement to the DB
                try {
		Statement myStmt = myConn.createStatement();		              
                ////////// this is for the select statement
		  try {
		myStmt.executeUpdate(sql);
            } 
		catch (Exception e)
		{
			System.out.println(e);
		} 
		}
		catch (Exception e)
		{
			System.out.println("Error connecting to database");
		}                
                // have to close the connection to the database at the end of the query
                 myConn.close();
}
		catch (Exception e)
		{
			System.out.println(e);
		}
        System.out.println(sql);     
    }
    /**this is how properties are deleted from the database*/
    public void deleteProperty(String address){
        String dbURL = "jdbc:derby://localhost:1527/RealEstateDB";
		String user = "NewWestSolutions";
		String pass = "newwest";     
        String sql = "DELETE FROM HOUSE_TABLE WHERE HOUSEADDRESS = \'" + address + "\'";        
        try {
                // set up the connection to the DB
                Connection myConn = DriverManager.getConnection(dbURL, user, pass);                
                // this allows you to make even send a statement to the DB
                try {
		Statement myStmt = myConn.createStatement();		              
                ////////// this is for the select statement
		  try {
		myStmt.executeUpdate(sql);
            } 
		catch (Exception e)
		{
			System.out.println(e);
		} 
		}
		catch (Exception e)
		{
			System.out.println("Error connecting to database");
		}                
                // have to close the connection to the database at the end of the query
                 myConn.close();}
		catch (Exception e)
		{
			System.out.println(e);
		}
         System.out.println(sql);
    }
    /**This gets the fields needed for the edit or delete property screens*/
    public String[] fillChange(String address){
        String[] output = new String[10];
        String dbURL = "jdbc:derby://localhost:1527/RealEstateDB";
		String user = "NewWestSolutions";
		String pass = "newwest";
        //this creates the sql statement
        String sql = "SELECT * FROM HOUSE_TABLE WHERE HOUSEADDRESS = \'" + address + "\'";
        System.out.println(address);
        try {
                // set up the connection to the DB
                Connection myConn = DriverManager.getConnection(dbURL, user, pass);                
                // this allows you to make even send a statement to the DB
                try {
		Statement myStmt = myConn.createStatement();		              
                ////////// this is for the select statement
		  try {
		ResultSet myRs = myStmt.executeQuery(sql);
		//this while generates the output from the database
			myRs.next();
                        output[0] = myRs.getString("houseaddress");
                        output[1] = myRs.getString("propertytype");
			output[2] = myRs.getString("city");
                        output[3] = myRs.getString("price");
                        output[4] = myRs.getString("numfullbathroom");
                        output[5] = myRs.getString("numbathroomhalf");
                        output[6] = myRs.getString("numbedroom");
                        output[7] = myRs.getString("agentid");
                        output[8] = myRs.getString("lotsize");
                        output[9] = myRs.getString("levels");                       
            } 
		catch (Exception e)
		{
			System.out.println(e);
		} 
		}
		catch (Exception e)
		{
			System.out.println("Error connecting to database");
		}                
                // have to close the connection to the database at the end of the query
                 myConn.close();}
		catch (Exception e)
		{
			System.out.println(e);
		}
        return output;
    }
    /**This gets the house id using the house address*/
    public int getHouseID(String address){
        int houseid = 0;      
      String dbURL = "jdbc:derby://localhost:1527/RealEstateDB";
		String user = "NewWestSolutions";
		String pass = "newwest";
        String sql = "SELECT * FROM HOUSE_TABLE WHERE HOUSEADDRESS = \'" + address + "\'";        
        try {
                // set up the connection to the DB
                Connection myConn = DriverManager.getConnection(dbURL, user, pass);                
                // this allows you to make even send a statement to the DB
                try {
		Statement myStmt = myConn.createStatement();		              
                ////////// this is for the select statement
		  try {
		ResultSet myRs = myStmt.executeQuery(sql);		
			while (myRs.next()) {
                        houseid = (myRs.getInt("houseid"));                                                                    
		}
            } 
		catch (Exception e)
		{
			System.out.println(e);
		} 
		}
		catch (Exception e)
		{
			System.out.println("Error connecting to database");
		}                
                // have to close the connection to the database at the end of the query
                 myConn.close();
}
		catch (Exception e)
		{
			System.out.println(e);
		}
      return houseid;
    }
    /**This gets the agent's id with the agents name*/
    public int getAgentID(String agent){
        int agentid = 0;
      String dbURL = "jdbc:derby://localhost:1527/RealEstateDB";
		String user = "NewWestSolutions";
		String pass = "newwest";
        String sql = "SELECT * FROM AGENT_TABLE WHERE AGENTNAME = \'" + agent + "\'";
        
        try {
                // set up the connection to the DB
                Connection myConn = DriverManager.getConnection(dbURL, user, pass);                
                // this allows you to make even send a statement to the DB
                try {
		Statement myStmt = myConn.createStatement();		              
                ////////// this is for the select statement
		  try {
		ResultSet myRs = myStmt.executeQuery(sql);		
			while (myRs.next()) {
                        agentid = (myRs.getInt("agentid"));                                                                    
		}
            } 
		catch (Exception e)
		{
			System.out.println(e);
		} 
		}
		catch (Exception e)
		{
			System.out.println("Error connecting to database");
		}                
                // have to close the connection to the database at the end of the query
                 myConn.close();
}
		catch (Exception e)
		{
			System.out.println(e);
		}
      return agentid;
    }
    /**This adds the transaction information after a sale*/
    /**As well as marking the house as sold on the house table*/
    public void markSold(double gst, double com, int lA, String sA, double fP, int hI){
         // 1) create a java calendar instance
        Calendar calendar = Calendar.getInstance(); 
        // 2) get a java.util.Date from the calendar instance.
        //    this date will represent the current instant, or "now".
        java.util.Date now = calendar.getTime();
        // 3) a java current time (now) instance
        java.sql.Timestamp c = new java.sql.Timestamp(now.getTime());  
      String dbURL = "jdbc:derby://localhost:1527/RealEstateDB";
		String user = "NewWestSolutions";
		String pass = "newwest";
       String sql = "INSERT INTO TRANSACTION_TABLE (DATEOFSALE, SAGENTNAME, FINALPRICE, GST, AGENTID, HOUSEID, COMMISSION) VALUES(";   
       sql += "\'"+ c + "\',\'" + sA + "\'," + fP + "," + gst + ", " + lA + "," + hI + ", " + com + ")";
        try {
                // set up the connection to the DB
                Connection myConn = DriverManager.getConnection(dbURL, user, pass);                
                // this allows you to make even send a statement to the DB
                try {
		Statement myStmt = myConn.createStatement();
		              
                ////////// this is for the select statement
		  try {
		myStmt.executeUpdate(sql);
            } 
		catch (Exception e)
		{
			System.out.println(e);
		} 
		}
		catch (Exception e)
		{
			System.out.println("Error connecting to database");
		}                
                // have to close the connection to the database at the end of the query
                 myConn.close();
}
		catch (Exception e)
		{
			System.out.println(e);
		}     
      System.out.println(sql);
        sql = "UPDATE HOUSE_TABLE SET ";
        sql += "SOLD = true ";
        sql += "WHERE HOUSEID = " + hI;
        try {
                // set up the connection to the DB
                Connection myConn = DriverManager.getConnection(dbURL, user, pass);                
                // this allows you to make even send a statement to the DB
                try {
		Statement myStmt = myConn.createStatement();		              
                ////////// this is for the select statement
		  try {
		myStmt.executeUpdate(sql);
            } 
		catch (Exception e)
		{
			System.out.println(e);
		} 
		}
		catch (Exception e)
		{
			System.out.println("Error connecting to database");
		}
                // have to close the connection to the database at the end of the query
                 myConn.close();
}
		catch (Exception e)
		{
			System.out.println(e);
		}
        System.out.println(sql);
    }
    /**This gets the agent information for the edit and delete agent GUIs*/   
    public String[] getAgentDetail(int selected){
        String values[] = new String[5];
        String dbURL = "jdbc:derby://localhost:1527/RealEstateDB";
		String user = "NewWestSolutions";
		String pass = "newwest";
        //this creates the sql statement
        String sql = "SELECT * FROM AGENT_TABLE WHERE AGENTID = " + selected;        
        try {
                // set up the connection to the DB
                Connection myConn = DriverManager.getConnection(dbURL, user, pass);                
                // this allows you to make even send a statement to the DB
                try {
		Statement myStmt = myConn.createStatement();		              
                ////////// this is for the select statement
		  try {
		ResultSet myRs = myStmt.executeQuery(sql);
		//this while generates the output from the database
			myRs.next();
                        values[0] = myRs.getString("agentname");
                        values[1] = myRs.getString("phonenumber");
			values[2] = myRs.getString("age");
                        values[3] = myRs.getString("password");
                        values[4] = myRs.getString("accounttype");                       
            } 
		catch (Exception e)
		{
			System.out.println(e);
		} 
		}
		catch (Exception e)
		{
			System.out.println("Error connecting to database");
		}                
                // have to close the connection to the database at the end of the query
                 myConn.close();
}
		catch (Exception e)
		{
			System.out.println(e);
		}
        return values;
    }
    /**This adds agents to the agent table*/
    public void addAgent(String info[]){         
      // 1) create a java calendar instance
        Calendar calendar = Calendar.getInstance(); 
        // 2) get a java.util.Date from the calendar instance.
        //    this date will represent the current instant, or "now".
        java.util.Date now = calendar.getTime();
        // 3) a java current time (now) instance
        java.sql.Timestamp c = new java.sql.Timestamp(now.getTime()); 
      String dbURL = "jdbc:derby://localhost:1527/RealEstateDB";
		String user = "NewWestSolutions";
		String pass = "newwest";               
       String sql = "INSERT INTO AGENT_TABLE (AGENTNAME, PHONENUMBER, AGE, PASSWORD, ACCTCREATED, ACCOUNTTYPE) VALUES(";   
       sql += "\'"+info[0] + "\',\'" + info[1] + "\'," +info[2] + ",\'" +info[3] + "\', \'" + c + "\',\'" + info[4] + "\')";
       try {
                // set up the connection to the DB
                Connection myConn = DriverManager.getConnection(dbURL, user, pass);                
                // this allows you to make even send a statement to the DB
                try {
		Statement myStmt = myConn.createStatement();		              
                ////////// this is for the select statement
		  try {
		myStmt.executeUpdate(sql);
            } 
		catch (Exception e)
		{
			System.out.println(e);
		} 
		}
		catch (Exception e)
		{
			System.out.println("Error connecting to database");
		}               
                // have to close the connection to the database at the end of the query
                 myConn.close();}
		catch (Exception e)
		{
			System.out.println(e);
		}     
      System.out.println(sql);     
    }
    /**This is used to edit agents*/
    public void editAgent(String info[],int selected){
        String dbURL = "jdbc:derby://localhost:1527/RealEstateDB";
		String user = "NewWestSolutions";
		String pass = "newwest";     
        String sql = "UPDATE AGENT_TABLE SET ";
        sql += "AGENTNAME = \'" + info[0] + "\', PHONENUMBER =\'" + info[1] + "\', AGE = " + info[2] + ", PASSWORD = \'" + info[3] + "\' ,ACCOUNTTYPE = \'" + info[4] + "\'";
        sql += "WHERE AGENTID = " + selected;
        try {
                // set up the connection to the DB
                Connection myConn = DriverManager.getConnection(dbURL, user, pass);                
                // this allows you to make even send a statement to the DB
                try {
		Statement myStmt = myConn.createStatement();		              
                ////////// this is for the select statement
		  try {
		myStmt.executeUpdate(sql);
            } 
		catch (Exception e)
		{
			System.out.println(e);
		} 
		}
		catch (Exception e)
		{
			System.out.println("Error connecting to database");
		}                
                // have to close the connection to the database at the end of the query
                 myConn.close();
}
		catch (Exception e)
		{
			System.out.println(e);
		}
        System.out.println(sql);
    }
    /**This is used to remove agents*/
    public void deleteAgent(int id){
        String dbURL = "jdbc:derby://localhost:1527/RealEstateDB";
		String user = "NewWestSolutions";
		String pass = "newwest";     
        String sql = "DELETE FROM AGENT_TABLE WHERE AGENTID = " + id;        
        try {
                // set up the connection to the DB
                Connection myConn = DriverManager.getConnection(dbURL, user, pass);                
                // this allows you to make even send a statement to the DB
                try {
		Statement myStmt = myConn.createStatement();
		  try {
		myStmt.executeUpdate(sql);
            } 
		catch (Exception e)
		{
			System.out.println(e);
		} 
		}
		catch (Exception e)
		{
			System.out.println("Error connecting to database");
		}                
                // have to close the connection to the database at the end of the query
                 myConn.close();
}
		catch (Exception e)
		{
			System.out.println(e);
		}
         System.out.println(sql);
    }
}